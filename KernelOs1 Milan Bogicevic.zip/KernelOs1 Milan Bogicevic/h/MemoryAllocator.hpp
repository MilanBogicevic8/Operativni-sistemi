#ifndef _MemoryAllocator_hpp_
#define _MemoryAllocator_hpp_

#include "../lib/hw.h"

#define PORAVNAJ(size) ((size+MEM_BLOCK_SIZE)&(~MEM_BLOCK_SIZE))



struct BlockHeader {
    uint32 size;
    struct BlockHeader *next;
};

void memory_initialize();
// free je iz kolokkvijuma sept 2015
int tryToJoin(BlockHeader* cur);
int free(void *pa);
// kalloc je sa kolokvijuma avg 2020
void * kalloc(size_t size);

#endif
