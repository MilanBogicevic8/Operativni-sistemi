#ifndef _provera_periodic_threada_hpp_
#define _provera_periodic_threada_hpp_

#include "../h/syscall_cpp.hpp"

//#include "printing.hpp"
#include "print.hpp"
bool finishedA = false;
bool finishedB = false;
bool finishedC = false;
bool finishedD = false;


class WorkerA: public PeriodicThread {
public:
    WorkerA():PeriodicThread(10) {}

    void periodicActivation() override {
        /*printString("Hello");
        printString(" ");
        printInt(10);
        printString("\n");*/
    }
};

class WorkerB: public PeriodicThread {
    void workerBodyB(void* arg);
public:
    WorkerB():PeriodicThread(20) {}

    void periodicActivation() override {
        /*printString("Hello");
        printString(" ");
        printInt(20);
        printString("\n");*/
    }
};

class WorkerC: public PeriodicThread {
public:
    WorkerC():PeriodicThread(30) {}

    void periodicActivation() override {
        /*printString("Hello");
        printString(" ");
        printInt(30);
        printString("\n");*/
    }
};

class WorkerD: public PeriodicThread {
int i=0;
public:
    WorkerD():PeriodicThread(40) {}

    void periodicActivation() override {
        /*printString("Hello");
        printString(" ");
        printInt(40);
        printString("\n");*/
        i++;
        if(i==3){
            finishedA=finishedB=finishedC=finishedD=true;
        }
    }
};


void provera() {
    Thread* threads[4];

    threads[0] = new WorkerA();
    //printString("ThreadA created\n");

    threads[1] = new WorkerB();
    //printString("ThreadB created\n");

    threads[2] = new WorkerC();
    //printString("ThreadC created\n");

    threads[3] = new WorkerD();
    //printString("ThreadD created\n");

    for(int i=0; i<4; i++) {
        threads[i]->start();
    }

    while (!(finishedA && finishedB && finishedC && finishedD)) {
        Thread::dispatch();
    }

    for (auto thread: threads) { delete thread; }
}

#endif