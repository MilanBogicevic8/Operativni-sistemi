#ifndef _ulaz_izlaz_hpp_
#define _ulaz_izlaz_hpp_

#include "tcb.hpp"

struct BNode{
    TCB* tcb=nullptr;
    BNode* next=nullptr;
};

void blokiraj_nit_znak();

void deblokiraj_nit_znak();


#endif