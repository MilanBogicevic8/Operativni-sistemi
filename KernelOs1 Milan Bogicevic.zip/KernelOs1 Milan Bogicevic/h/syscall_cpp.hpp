#ifndef _syscall_cpp
#define _syscall_cpp

#include "syscall_c.h"

extern void* operator new(size_t);
extern void operator delete(void*) noexcept;

class Thread{
    // s obzirom na to da nema puno linija koda implementiracu celu klasu ovd
    // a ne u cpp-u
public:
    Thread(void (*body)(void*),void* arg) {
        if(body){
            thread_create(&myHandle,body,arg);
        }
    }

    virtual ~Thread()
    {
       //delete myHandle;
    }
    int start() { return thread_create(&myHandle, starter, this);}

    // mora da se uvede neka staticka funkcija
    //zbog polimorfizma , kao na 5. vezbama
    static void starter(void* argument){
        Thread* tr=(Thread*)argument;
        if(argument) tr->run();
    }

    static void dispatch(){thread_dispatch();}
    static int sleep(time_t t){
        return time_sleep(t);
    }
protected:
    Thread(){}
    virtual void run(){}

private:
    thread_t myHandle;

};

// s obzirom da se u sustini zovu sistemski pozivi klasa semaphore
// ce takodje biti implementirana ovde

class Semaphore{
public:
    Semaphore(unsigned init=1){
        sem_open(&myHandle,init);
    }
    virtual ~Semaphore(){
        //delete myHandle;
    }

    int wait(){
        if(myHandle) {
         int i= sem_wait(myHandle);
         return i;
        }
        return -1;
    }
    int signal(){
        if(myHandle) {
            int i=sem_signal(myHandle);
            return i;
        }
        return -1;
    }

private:
    sem_t myHandle;
};


class PeriodicThread:public Thread{

    int num;
protected:
    explicit PeriodicThread(time_t periodical);

    virtual void periodicActivation(){}

private:
    time_t periodical=0;
    static void aktivacija(void* arg){
        PeriodicThread* thr=(PeriodicThread*)arg;
        if(thr) thr->periodicActivation();
    }
    void run() override;
};

class Console{
public:
    static char getc(){
        return ::getc();
    }
    static void putc (char c){
        ::putc(c);
    }
};
#endif