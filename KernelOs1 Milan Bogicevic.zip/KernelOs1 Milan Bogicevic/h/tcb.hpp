//
// Created by marko on 20.4.22..
//

#ifndef OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_TCB_HPP
#define OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_TCB_HPP

#include "../lib/hw.h"
#include "scheduler.hpp"
#include "../h/sys_abi.hpp"

enum State{FINISHED,READY,BLOCKED,SLEEPY,RUNNING};

// Thread Control Block
class TCB
{
public:


    ~TCB() {
        if(stack){
            DoKernel=true;
            delete[] stack;
            DoKernel=false;
        }
    }

    static int br;
    int broj=++br;

    bool isFinished() const { return finished; }

    void setFinished(bool value) { finished = value; }

    uint64 getTimeSlice() const { return timeSlice; }
    static void setTimeSliceCounter(uint64 t=0){
        timeSliceCounter=t;
    }
    using Body = void (*)(void*);

    static TCB *createThread(Body body, void* arg,void* stack_space);

    static void yield();

    static TCB *running;
    static TCB* idle;

    TCB(Body body=nullptr,void* arg=nullptr, uint64 timeSlice=0,void* stack_space=nullptr)
    {
        this->body=body;
        this->stack=(uint64*)(stack_space);
        this->context={(uint64) &threadWrapper,
                       stack != nullptr ? (uint64) &stack[STACK_SIZE] : 0
        };
        this->timeSlice=timeSlice;
        this->finished=false;
        this->arg=arg;
        this->stanje=READY;
        if (body != nullptr && broj!=2) { Scheduler::put(this); }
    }

    struct Context
    {
        uint64 ra;
        uint64 sp;
    };
    State stanje;
    Body body;
    uint64 *stack;
    Context context;
    uint64 timeSlice;
    bool finished;
    void* arg;
    friend class Riscv;

    static void threadWrapper();

    static void contextSwitch(Context *oldContext, Context *runningContext);
public:
    static void dispatch();
private:
public:
    static uint64 timeSliceCounter;

    static uint64 constexpr STACK_SIZE = 4096;
    static uint64 constexpr TIME_SLICE = DEFAULT_TIME_SLICE;

    friend int kthread_create(thread_t* handle,void(*start_routine)(void*),void* arg,void* stack_space);
    friend int kthread_dispatch();
    friend int kthread_exit();
    friend class _sem;
};

#endif //OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_TCB_HPP
