#ifndef _console_handle_hpp_
#define _console_handle_hpp_

#include "../lib/hw.h"

#define BACKSPACE 0x100
#define C(x)  ((x)-'@')  // kontol+ nesto
#define IOReg(reg) ((volatile unsigned char *)(reg))
#define RedReg(reg) (*(IOReg(reg)))
#define WritReg(reg, v) (*(IOReg(reg)) = (v))

void ioputc_async(int c);
void ioputc(int c);
void iostart();
int
iogetc();
void
iointr();
void
ioconsputc(int c);
int
ioconsolewrite(char c);
int
ioconsoleread();
void
ioconsoleintr(int c);

#endif