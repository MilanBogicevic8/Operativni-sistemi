#ifndef _KernAsin_hpp_
#define _KernAsin_hpp_



class TCB;
struct Nodes{
    TCB* tcb=nullptr;
    int time=0;
    Nodes* next=nullptr;
};

void dodaj(int tim);
int azuriraj();
void ukloni();




#endif