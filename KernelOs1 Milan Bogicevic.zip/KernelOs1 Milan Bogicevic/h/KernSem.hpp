#ifndef _KernSem_hpp_
#define _KernSem_hpp_

#include "list.hpp"
#include "../h/tcb.hpp"


struct Node{
    TCB* tcb=nullptr;
    Node* next=nullptr;
};

class _sem{
private:
    static Node slobodni[100];
    static int bit_niz[100];
public:

    Node* head=nullptr,*tail=nullptr;

    _sem(int init=1):val(init){}
    int wait(){
        if(waitRet<0) return waitRet;
        if(--val<0) block();
        return waitRet;
    }// kao u knjizi samo sto se ne maskiraju prekidi jer su vec maskirani
    int signal(){
        if(++val<=0) unblock();
        return 1;
    }
    int oslobodi(){
        Node* ptr=head;
        if(head) {
            while (ptr) {
                if (ptr->tcb->stanje == FINISHED) continue;
                ptr->tcb->stanje = READY;
                Scheduler::put(ptr->tcb);// vracamo niti u red spremnih
                //ptr = lista.removeFirst();
                int i=0;
                for(;i<100;i++){
                    if(ptr==&slobodni[i]){
                        bit_niz[i]=0;
                    }
                }
                ptr=ptr->next;
            }
        }
        waitRet=-1;
        return 0;
    }
protected:
    void block();
    void unblock();
private:
    int val;
    int waitRet=0;
    //List<TCB> lista;
};




#endif