#ifndef OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_SCHEDULER_HPP
#define OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_SCHEDULER_HPP

#include "list.hpp"

class TCB;
struct Element{
    TCB* tcb=nullptr;
    Element* next=nullptr;
};
class Scheduler
{
private:
    static List<TCB> readyThreadQueue;
    static Element slobodni[100];
    static int bit_niz[100];
    static Element* head,*tail;
public:
    static TCB *get();

    static void put(TCB *tcb);

    static int count();

    static void put_priority(TCB* tcb);

};

#endif //OS1_VEZBE07_RISCV_CONTEXT_SWITCH_2_INTERRUPT_SCHEDULER_HPP
