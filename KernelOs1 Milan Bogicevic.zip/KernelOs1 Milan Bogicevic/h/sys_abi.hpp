#ifndef _sys_abi_hpp_
#define _sys_abi_hpp_

#include "../lib/hw.h"

class TCB;
typedef TCB* thread_t;
class _sem;
typedef _sem* sem_t;

uint64 syscall(uint64 a0,uint64 a1,uint64 a2,uint64 a3,uint64 a4,uint64 a5,uint64 a6);
uint64 kmem_alloc(size_t size);// 0x01
int kmem_free(void* pa);// 0x02
int kthread_dispatch();// 0x13
int kthread_create(thread_t* handle,void(*start_routine)(void*),void* arg,void* stack_size); //0x11
int kthread_exit();// 0x12
int ksem_open(uint64 handle,uint64 init);// 0x21
int ksem_close(uint64 handle); //0x22
int ksem_wait(uint64 id); //0x23
int ksem_signal(uint64 id); //0x24
char kgetc();//0x41
void kputc(char c); //0x42
typedef unsigned long time_t;
int ktime_sleep(int tim);// 0x31

#endif