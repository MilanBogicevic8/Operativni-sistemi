#include "../h/console_handle.hpp"
#include "../h/ulaz_izlaz.hpp"
//#define _izlaz_

//#ifndef _izlaz_
/*
#define IO_TX_BUF_SIZE 128
#define INPUT_BUF_SIZE 128
char io_tx_buf[IO_TX_BUF_SIZE];
uint64 tail_buf=0; // io_tx_buf[io_tx_w % IO_TX_BUF_SIZE]
uint64 head_buf=0; // io_tx_buf[io_tx_r % IO_TX_BUF_SIZE]
uint64 duz1=0;



void ioputc_async(int c) // direktno ispis na konzolu
{
    // asinhroni ispis na konzolu  bez baferovanja
    while((RedReg(CONSOLE_STATUS) & CONSOLE_TX_STATUS_BIT) == 0);
    WritReg(CONSOLE_TX_DATA, c);

}

void ioputc(int c) //salje znake u buf pa kao moze onda i na konzolu
{
    if(duz1!=IO_TX_BUF_SIZE){
        io_tx_buf[tail_buf++] = c;
        if(tail_buf==IO_TX_BUF_SIZE) tail_buf=0;
        duz1++;
        iostart();
    }
}

void iostart() //salje znake na konzolu
{
    while(true){
        if(duz1==0){
            return;
        }// vrati se ako je bafer prazan

        if((RedReg(CONSOLE_STATUS) & CONSOLE_TX_STATUS_BIT) == 0){
            return;
        }// ne moze da se transfera vise znaka

        int c = io_tx_buf[head_buf++];
        if(head_buf==IO_TX_BUF_SIZE) head_buf=0;
        duz1--;
        WritReg(CONSOLE_TX_DATA, c);
    }
}

int iogetc() // cita znak sa konzole
{
    if(RedReg(CONSOLE_STATUS) & CONSOLE_RX_STATUS_BIT){
        //ako je znak spreman


        char karakter=RedReg(CONSOLE_RX_DATA);

        return karakter;

    } else {
        return -1;
    }
}

void iointr()
{
    // citanje i  ispis iz prekidne rutine
    while(true){
        int c = iogetc();
        if(c == -1) {
            break;
        }
        ioconsoleintr(c);
    }
    // ispis karatera na konzolu
    iostart();

}






char buf[INPUT_BUF_SIZE];
uint64 r=0;  // Read index
uint64 w=0;  // Write index
uint64 e=0;  // Edit index

uint64 duz2=0;
uint64 duz3=0;

void ioconsputc(int c) //asinhrono ispisuje direktno na konzolu bez cuvanja
{
    if(c == BACKSPACE){
        // ako se napise backspace
        ioputc_async('\b'); ioputc_async(' '); ioputc_async('\b');
    } else {
        ioputc_async(c);
    }
    duz2--;
}

int ioconsolewrite(char c) // salje jedan char u cuvanje na buf
{

    if(c>=8 && c<127){
        ioputc(c);
    }
    else{return -1;}
    return 1;
}

int ioconsoleread()
{


    if(duz3==0){
        return -1;
    }
    int c;
    c = buf[r];
    if(r==INPUT_BUF_SIZE) r=0;

    duz2--;
    duz3--;
    return c;
}


void ioconsoleintr(int c)
{

        //C('H'): // bekspejs
        //'\x7f': // delete, u principu isto
        if(c==C('H') || c=='\x7f') {
            if (e != w) {
                e--;
                if(e<0) e=IO_TX_BUF_SIZE;
                ioconsputc(BACKSPACE);
            }
        }
        else {
            if (c!=0 && duz2<INPUT_BUF_SIZE) {
                c = (c == '\r') ? '\n' : c;

                // za terminal ako se ehuje
                //ioconsputc(c);

                // upis u bufer reaader

                buf[e++] = c;
                if(e==INPUT_BUF_SIZE) e=0;
                duz2++;
                if (c == '\n' || duz2==INPUT_BUF_SIZE){ //} || c == C('D') || iocons.e == iocons.r + INPUT_BUF_SIZE) {
                    // stigla cela linija
                    w = e;
                    duz3=duz2;
                }
            }
        }

        void inicijalizuj_izlaz_ulaz(){
    for(int i=0;i<INPUT_BUF_SIZE;i++){
        io_tx_buf[i]=0;
    }
    for(int i=0;i<INPUT_BUF_SIZE;i++){
        buf[i]=0;
    }

    tail_buf=head_buf=0;
    r=w=e=0;
}
}*/
//#elifdef _izlaz_

#define IO_TX_BUF_SIZE 128
#define INPUT_BUF_SIZE 128
char io_tx_buf[IO_TX_BUF_SIZE];
uint64 tail_buf=0; // io_tx_buf[io_tx_w % IO_TX_BUF_SIZE]
uint64 head_buf=0; // io_tx_buf[io_tx_r % IO_TX_BUF_SIZE]



void ioputc_async(int c) // direktno ispis na konzolu
{
    // asinhroni ispis na konzolu  bez baferovanja
    while((RedReg(CONSOLE_STATUS) & CONSOLE_TX_STATUS_BIT) == 0);
    WritReg(CONSOLE_TX_DATA, c);

}

void ioputc(int c) //salje znake u buf pa kao moze onda i na konzolu
{
    if(tail_buf != head_buf + IO_TX_BUF_SIZE){
        io_tx_buf[tail_buf % IO_TX_BUF_SIZE] = c;
        tail_buf += 1;
        iostart();
        return;
    }
}

void iostart() //salje znake na konzolu
{
    while(true){
        if(tail_buf == head_buf){
            return;
        }// vrati se ako je bafer prazan

        if((RedReg(CONSOLE_STATUS) & CONSOLE_TX_STATUS_BIT) == 0){
            return;
        }// ne moze da se transfera vise znaka

        int c = io_tx_buf[head_buf % IO_TX_BUF_SIZE];
        head_buf+= 1;
        WritReg(CONSOLE_TX_DATA, c);
    }
}

int iogetc() // cita znak sa konzole
{
    if(RedReg(CONSOLE_STATUS) & CONSOLE_RX_STATUS_BIT){
        //ako je znak spreman


        char karakter=RedReg(CONSOLE_RX_DATA);

        return karakter;

    } else {
        return -1;
    }
}

void iointr()
{
    // citanje i  ispis iz prekidne rutine
    while(true){
        int c = iogetc();
        if(c == -1) {
            break;
        }
        ioconsoleintr(c);
    }
    // ispis karatera na konzolu
    iostart();

}


void ioconsputc(int c) //asinhrono ispisuje direktno na konzolu bez cuvanja
{
    if(c == BACKSPACE){
        // ako se napise backspace
        ioputc_async('\b'); ioputc_async(' '); ioputc_async('\b');
    } else {
        ioputc_async(c);
    }
}


char buf[INPUT_BUF_SIZE]={0};
uint64 r=0;  // Read index
uint64 w=0;  // Write index
uint64 e=0;  // Edit index


int ioconsolewrite(char c) // salje jedan char u cuvanje na buf
{

    if(c){ioputc(c);}
    else{return -1;}
    return 1;
}

int ioconsoleread()
{
    int c;

    if(r == w){
        return -1;
    }

    c = buf[r++ % INPUT_BUF_SIZE];

    return c;
}


void ioconsoleintr(int c)
{

        if(c==C('H') || c=='\x7f') { // bekspejs
            if (e != w) {
                e--;
                ioconsputc(BACKSPACE);
            }
        }
        else {
                if (c != 0 && e - r < INPUT_BUF_SIZE) {
                    c = (c == '\r') ? '\n' : c;

                    // za terminal ako se ehuje
                    //ioconsputc(c);

                    // upis u bufer reaader
                    buf[e++ % INPUT_BUF_SIZE] = c;

                    if (c == '\n' || c == C('D') || e == r + INPUT_BUF_SIZE) {
                        // stigla cela linija
                        w = e;
                        deblokiraj_nit_znak();
                    }
                }
            }
}



void inicijalizuj_izlaz_ulaz(){
    for(char & i : io_tx_buf){
        i=0;
    }
    for(char & i : buf){
        i=0;
    }

    tail_buf=head_buf=0;
    r=w=e=0;
}
//#endif

