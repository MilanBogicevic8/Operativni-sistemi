//
// Created by marko on 20.4.22..
//

#include "../lib/hw.h"
#include "../h/syscall_c.h"

#include "../h/MemoryAllocator.hpp"

extern bool DoKernel;

void *operator new(size_t size)
{
    if(!DoKernel){return mem_alloc(size);}
    else{return kalloc((size/MEM_BLOCK_SIZE + (size%MEM_BLOCK_SIZE?1:0))*MEM_BLOCK_SIZE);}
}

void *operator new[](size_t size)
{
    if(!DoKernel){return mem_alloc(size);}
    else{return kalloc((size/MEM_BLOCK_SIZE + (size%MEM_BLOCK_SIZE?1:0))*MEM_BLOCK_SIZE);}
}

void operator delete(void *p) noexcept
{
    if(!DoKernel){
        mem_free(p);
    }else{
        free(p);
    }
}

void operator delete[](void *p) noexcept
{
    if(!DoKernel){
        mem_free(p);
    }else{
        free(p);
    }
}

