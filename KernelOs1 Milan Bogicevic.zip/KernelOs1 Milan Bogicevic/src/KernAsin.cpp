#include "../h/KernAsin.hpp"
#include "../h/tcb.hpp"

extern void kprintInteger(uint64 integer);
extern void kprintString(char const *string);

Nodes* head=nullptr,*tail=nullptr;
Nodes slobodni2[100];
int bit_niz2[100]={0};

void dodaj(int tim){
    if(tim==0) return;
    int i=0;
    for(;i<100;i++){
        if(bit_niz2[i]==0){
            break;
        }
    }
    if(i<100){
        TCB* pokaz=TCB::running;
        bit_niz2[i]=1;
        Nodes* node=&slobodni2[i];
        node->tcb=pokaz;
        node->time=tim;
        node->next=nullptr;
        int t1=tim;
        /*kprintString("\n-1");
        kprintInteger(t1);
        kprintString("-\n");*/
        Nodes* pok1=nullptr,*pok2=head;
        while(pok2){
            if((t1-(pok2->time))>=0){
                t1=t1-pok2->time;
                pok1=pok2;
                pok2=pok2->next;
            }else{
                break;
            }
        }
        node->time=t1;
        /*kprintString("\n-2");
        kprintInteger(t1);
        kprintString("-\n");*/
        if(!pok1){
            node->next=head;
            if(!head){
                tail=node;
            }else{
                head->time=head->time-node->time;
            }
            head=node;

        }else{
            pok1->next=node;
            node->next=pok2;
            if(pok1==tail){
                tail=node;
            }
        }

    }

    TCB *old = TCB::running;
    TCB* nit = Scheduler::get();
    TCB::running=nit;
    TCB::contextSwitch(&old->context, &nit->context);
}



int azuriraj(){

    int ik=0;
    if(head) {
        head->time = head->time - 1;
        //Nodes *pok = head;
        while (head) {
            if (head->time == 0) {
                ik++;
                TCB *thr = head->tcb;
                Scheduler::put(thr);
                int j=0;
                for(;j<100;j++){
                    if(head==&slobodni2[j]){
                        bit_niz2[j]=0;
                        break;
                    }
                }
            } else {
                break;
            }
            head = head->next;
        }
    }
    if(!head) tail=nullptr;

    return ik;
}



void ukloni(){
    Nodes* tek=head,*pret=nullptr;
    while(tek){
        if(tek->time!=0){
            pret=tek;
            tek=tek->next;
        }else{
            Nodes* stari=tek;
            TCB* thr=stari->tcb;
            tek=tek->next;
            if(!pret){
                head=tek;
            }else{
                pret->next=tek;
            }
            stari->tcb->stanje=READY;
            Scheduler::put(thr);
            int j=0;
            for(;j<100;j++){
                if(stari==&slobodni2[j]){
                    bit_niz2[j]=0;
                    break;
                }
            }
        }
    }
}