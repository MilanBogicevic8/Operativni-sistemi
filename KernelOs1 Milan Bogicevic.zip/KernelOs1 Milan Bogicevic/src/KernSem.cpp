#include "../h/KernSem.hpp"
#include "../h/scheduler.hpp"
#include "../lib/console.h"

Node _sem::slobodni[100];
int _sem::bit_niz[100]={0};


void _sem::block(){
    TCB::running->stanje=BLOCKED;
    TCB* oldThread=TCB::running;// running se blokira na semaforu

    //lista.addLast(oldThread);

    int i=0;
    for(;i<100;i++){
        if(bit_niz[i]==0){
            break;
        }
    }
    Node* slob=&slobodni[i];
    slob->tcb=oldThread;
    slob->next=nullptr;
    if(i<100) {
        bit_niz[i]=1;
        if (tail) {
            tail->next = slob;
            tail = slob;
        } else {
            head = tail = slob;
        }

        TCB::running = Scheduler::get();// izvlaci se nova nit iz scheduler
        TCB::running->stanje = READY;
        TCB::contextSwitch(&oldThread->context, &TCB::running->context);
    }
}


void _sem::unblock(){
    //TCB* thread=lista.removeFirst();
    if (!head) { return; }

    Node *elem = head;
    head = head->next;
    if (!head) { tail = nullptr; }

    TCB *thr = elem->tcb;

    int i=0;
    for(;i<100;i++){
        if(elem==&slobodni[i]){
            bit_niz[i]=0;
        }
    }
    thr->stanje=READY; // ovde se vadi iz reda blokiranih niti i stavlja u scheduler
    Scheduler::put(thr);
}