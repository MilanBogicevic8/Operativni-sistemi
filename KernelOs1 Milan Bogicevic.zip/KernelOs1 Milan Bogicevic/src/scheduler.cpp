#include "../h/scheduler.hpp"
#include "../h/tcb.hpp"

List<TCB> Scheduler::readyThreadQueue;
Element Scheduler::slobodni[100];
int Scheduler::bit_niz[100]={0};
Element* Scheduler::head=nullptr;
Element* Scheduler::tail=nullptr;
TCB *Scheduler::get()
{
    if(Scheduler::count()==0) return TCB::idle;
    //return readyThreadQueue.removeFirst();

    Element *elem = head;
    head = head->next;
    if (!head) { tail = nullptr; }

    TCB *thr = elem->tcb;

    int i=0;
    for(;i<100;i++){
        if(elem==&slobodni[i]){
            bit_niz[i]=0;
            break;
        }
    }
    return thr;
}

void Scheduler::put(TCB *tcb) {
    if (tcb != TCB::idle) {
        //readyThreadQueue.addLast(tcb);
        int i = 0;
        for (; i < 100; i++) {
            if (bit_niz[i] == 0) {
                break;
            }
        }
        Element *slob = &slobodni[i];
        slob->tcb = tcb;
        slob->next = nullptr;
        if (i < 100) {
            bit_niz[i] = 1;
            if (tail) {
                tail->next = slob;
                tail = slob;
            } else {
                head = tail = slob;
            }

        }
    }
}

int Scheduler::count()
{
    Element* cur=head;
    int i=0;
    while(cur){
        i+=1;
        cur=cur->next;
    }
    return i;
}

void Scheduler::put_priority(TCB* tcb){
    if (tcb != TCB::idle) {
        //readyThreadQueue.addLast(tcb);
        int i = 0;
        for (; i < 100; i++) {
            if (bit_niz[i] == 0) {
                break;
            }
        }
        Element *slob = &slobodni[i];
        slob->tcb = tcb;
        slob->next = nullptr;
        if (i < 100) {
            bit_niz[i] = 1;
            if(head){
                slob->next=head;
                head=slob;
            }else{
                head=tail=slob;
            }

        }
    }
}