#include "../h/riscv.hpp"
#include "../h/tcb.hpp"
#include "../h/KernAsin.hpp"
#include "../h/console_handle.hpp"

extern void kprintInteger(uint64 integer);
extern void kprintString(char const* string);
extern volatile uint64 glob_povr_vrednost;


void Riscv::popSppSpie()
{
    //w_sstatus(r_sstatus() & ~((uint64)(1<<8)));

    __asm__ volatile ("csrw sepc, ra");
    mc_sstatus(1<<8);
    __asm__ volatile ("sret");
}

void Riscv::handleSupervisorTrap()
{

    uint64 a0;
    uint64 a1;
    uint64 a2;
    uint64 a3;
    uint64 a4;
    uint64 a5;
    uint64 a6;
    __asm__ volatile("mv %0,a0":"=r"(a0));
    __asm__ volatile("mv %0,a1":"=r"(a1));
    __asm__ volatile("mv %0,a2":"=r"(a2));
    __asm__ volatile("mv %0,a3":"=r"(a3));
    __asm__ volatile("mv %0,a4":"=r"(a4));
    __asm__ volatile("mv %0,a5":"=r"(a5));
    __asm__ volatile("mv %0,a6":"=r"(a6));
    uint64 scause = r_scause();

    if (scause == 0x0000000000000008UL || scause == 0x0000000000000009UL)
    {
        // interrupt: no; cause code: environment call from U-mode(8) or S-mode(9)
        uint64 sepc = r_sepc() + 4;
        uint64 sstatus = r_sstatus();
        glob_povr_vrednost=syscall(a0,a1,a2,a3,a4,a5,a6);
        w_sstatus(sstatus);
        w_sepc(sepc);
        mc_sstatus(1<<8);
        return;
    } else if (scause == 0x8000000000000001UL)
    {
        // interrupt: yes; cause code: supervisor software interrupt (CLINT; machine timer interrupt)

        int pov=azuriraj();

        TCB::timeSliceCounter++;
        //kprintInteger(pov);
        if(pov==0) {
        if (TCB::timeSliceCounter >= TCB::running->getTimeSlice()) {
                uint64 sepc = r_sepc();
                uint64 sstatus = r_sstatus();
                TCB::timeSliceCounter = 0;
                TCB::dispatch();
                w_sstatus(sstatus);
                w_sepc(sepc);
        }
        }
        mc_sip(SIP_SSIP);

    } else if (scause == 0x8000000000000009UL)
    {
        // interrupt: yes; cause code: supervisor external interrupt (PLIC; could be keyboard)
        //console_handler();

        int irq=plic_claim();
        if(irq==CONSOLE_IRQ) {
            iointr();
        }

        if(irq)plic_complete(irq);// iri povratna vrednost plic_claim

    } else
    {

        kprintInteger(r_scause());
        kprintString("\n ");
        kprintString("scause: ");
        kprintInteger(r_sstatus());
        kprintString("\n sepc:");
        kprintInteger(r_sepc());
        kprintString("\n");

        // unexpected trap cause
    }
}