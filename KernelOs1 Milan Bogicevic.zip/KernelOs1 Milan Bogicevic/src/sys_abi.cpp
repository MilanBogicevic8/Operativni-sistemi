#include "../h/sys_abi.hpp"
#include "../h/tcb.hpp"
#include "../h/KernSem.hpp"
#include "../h/MemoryAllocator.hpp"
#include "../h/KernAsin.hpp"
#include "../h/console_handle.hpp"
#include "../h/ulaz_izlaz.hpp"

char kgetc(){
    int c=-1;
    while(c==-1) {
        c = ioconsoleread();
        if (c == -1) {
            blokiraj_nit_znak();
        }
    }
    return c;
}

void kputc(char c){
    ioconsolewrite(c);
}

uint64 kmem_alloc(size_t size){
    return (uint64)kalloc((uint64)size*MEM_BLOCK_SIZE);

}

int kmem_free(void* pa){
    return free(pa);

}

int ktime_sleep(int tim){
    dodaj((int)tim);
    return 1;
}

int ksem_open(uint64 a1, uint64 a2){
    sem_t* semafor=(sem_t*)a1;
    DoKernel=true;
    *semafor=new _sem((int)a2);
    DoKernel=false;
    return (semafor!=nullptr?0:-1);
}

int ksem_close(uint64 a1){
    sem_t semafor=(sem_t)a1;
    return semafor->oslobodi();
}
int ksem_wait(uint64 a1){
    sem_t semafor=(sem_t)a1;
    return semafor->wait();
}

int ksem_signal(uint64 a1){
    sem_t semafor=(sem_t)a1;
    return semafor->signal();
}
uint64 syscall(uint64 a0,uint64 a1,uint64 a2,uint64 a3,uint64 a4,uint64 a5,uint64 a6){

    //switch(a6){
        if(a6==0x01){
            return kmem_alloc(a1);
        }
        else if(a6==0x02){
            return kmem_free((void*)a1);
        }
        else if(a6==0x11){
            return kthread_create((TCB**)a1,(void(*)(void*))a2,(void*)a3,(void*)a4);
        }

        else if(a6==0x12){
            return kthread_exit();
        }

        else if(a6==0x13){
            return kthread_dispatch();
        }

        else if(a6==0x21){
            return ksem_open(a1,a2);
        }
        else if(a6==0x22){ // sem_close(sem_t handle);
            return ksem_close(a1);
        }
        else if(a6==0x23){
            return ksem_wait(a1);
        }
        else if(a6==0x24){
            return ksem_signal(a1);
        }
        else if(a6==0x31)
        {
            return ktime_sleep((int)a1);
        }
        else if(a6==0x41){
            return (uint64)kgetc();
        }
        else if(a6==0x42){
            kputc((char)a1);
        }

        else{
            //
        }

    return -1;
}