#include "../h/syscall_c.h"



volatile bool DoKernel=false;

volatile uint64 glob_povr_vrednost=0;
volatile char glob_char;

uint64 pass_arguments(uint64 a0,uint64 a1,uint64 a2,uint64 a3,uint64 a4,uint64 a5,uint64 a6){

    __asm__ volatile("ecall");

    return glob_povr_vrednost;
}
void thread_dispatch()
{

    pass_arguments(0x13,0,0,0,0,0,0x13);

}

void* mem_alloc(size_t size){

     uint64 blokovi=(size/MEM_BLOCK_SIZE + (size%MEM_BLOCK_SIZE?1:0));
     return (void*)pass_arguments(0x01,blokovi,0,0,0,0,0x01);
}

int mem_free(void* pa)
{
    return (int) pass_arguments(0x02,(uint64)pa,0,0,0,0,0x02);
}

int thread_create(thread_t* handle,void(*start_routine)(void*),void* arg)
{

    uint64* stack=(start_routine != nullptr ? new uint64[DEFAULT_STACK_SIZE] : nullptr);

    pass_arguments(0x11,(uint64)(handle),(uint64)(start_routine),(uint64)(arg),(uint64)(stack),0,0x11);

    return (handle?0:-1);
}


int thread_exit()
{
    return (int)pass_arguments(0x12,0,0,0,0,0,0x12);

}


int sem_open(sem_t* handle,unsigned init)
{
    return (int)pass_arguments(0x21,(uint64)(handle),(uint64)(init),0,0,0,0x21);
}

int sem_close(sem_t handle)
{
    return (int)pass_arguments(0x22,(uint64)(handle),0,0,0,0,0x22);
}

int sem_wait(sem_t id)
{
    return (int)pass_arguments(0x23,(uint64)(id),0,0,0,0,0x23);
}

int sem_signal(sem_t id)
{
    return (int)pass_arguments(0x24,(uint64)(id),0,0,0,0,0x24);
}

int time_sleep(time_t tim){
    return (int)pass_arguments(0x31,tim,0,0,0,0,0x31);
}
char getc()
{
     uint64 arg=pass_arguments(0x41,0,0,0,0,0,0x41);
     return (char)arg;
}

void putc(char c)
{
    pass_arguments(0x42,(uint64)(c),0,0,0,0,0x42);
}
