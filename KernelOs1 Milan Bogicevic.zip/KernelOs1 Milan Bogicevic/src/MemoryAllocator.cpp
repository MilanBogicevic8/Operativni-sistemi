#include "../h/MemoryAllocator.hpp"


static BlockHeader* freeMemHead=nullptr;

//zbog optimizacije dodaj nule , da anuliras prethodni sadrzaj
void* fun_memset(void *dst, int c, int n)
{
    char *cdst = (char *) dst;
    int i;
    for(i = 0; i < n; i++){
        cdst[i] = c;
    }
    return dst;
}


void memory_initialize()
{

    BlockHeader* b=(BlockHeader*) PORAVNAJ((uint64)HEAP_START_ADDR);
    freeMemHead=b;
    freeMemHead->size= PORAVNAJ((uint64)HEAP_END_ADDR)-PORAVNAJ((uint64)HEAP_START_ADDR);
}

int tryToJoin(BlockHeader* cur){
    if(!cur) return 0;
    if(cur->next && (char*)cur+cur->size==(char*)(cur->next)){
        //ukloni cur->next onda
        cur->size+=cur->next->size;
        cur->next=cur->next->next;
        return 1;
    }else{
        return 0;
    }
}
//kol sept 2015
int free(void *pa) {

    BlockHeader *header = (BlockHeader *) ((char*)pa - sizeof(BlockHeader));
    //satvi sve delove koje oslobadjas na nula
    fun_memset(pa,'\0',header->size);
    //trazimo mesto gde umecemo slobodan segment
    BlockHeader *cur=nullptr;
    if(!freeMemHead || (char*)(header)<(char*)freeMemHead){
        cur=nullptr;
    }else{
        for(cur=freeMemHead;cur->next!=nullptr && (char*)(header)>(char*)(cur->next);cur=cur->next);
    }

    // uvezivanje slobodnog segmenta nakon cur

    if(cur) header->next=cur->next;
    else header->next=freeMemHead;
    if(cur) cur->next=header;
    else freeMemHead=header;

    tryToJoin(header);
    tryToJoin(cur);
    return 0;

}


//kol avg 2020
void * kalloc(size_t size) {

    //pronadji blok koji odgovara first fit algoritmom
    BlockHeader *blk = freeMemHead, *prev = nullptr;
    for (; blk != nullptr; prev = blk, blk = blk->next) {
        if (blk->size >= size) break;
    }
    //ako blok nije nadjen
    if (blk == nullptr) {
        return nullptr;
    }

    //uz alocirani blok ostaje zaglavlje da bi funkcija za oslobadjanje memorijskog bloka znala njegovu velicinu
    // s tim da kalloc vraca pokazivac na slobodan blok ispred zaglavlja
    //ako je blok nadjen alociraj ga, ovde se proverava da li je poravnato iako je u apiju to vec uradjeno
    size_t remainingSize = blk->size - size;
    if (remainingSize >= sizeof(BlockHeader) + MEM_BLOCK_SIZE) {
        blk->size = size;
        size_t offset = sizeof(BlockHeader) + size;
        BlockHeader* newBlk = (BlockHeader *) ((char*) blk + offset); // char ili int ?
        if (prev) prev->next = newBlk;
        else freeMemHead = newBlk;
        newBlk->next = blk->next;
        newBlk->size = remainingSize - sizeof(BlockHeader);
    } else {
        if (prev) prev->next = blk->next;
        else freeMemHead = blk->next;
    }
    blk->next = nullptr;
    return ((char*) blk + sizeof(BlockHeader)); // char ili int ?

}