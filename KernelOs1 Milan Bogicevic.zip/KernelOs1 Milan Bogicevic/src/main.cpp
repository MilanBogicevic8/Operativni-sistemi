#include "../h/tcb.hpp"
#include "../h/riscv.hpp"
#include "../h/MemoryAllocator.hpp"

extern bool DoKernel;
volatile int finidl=0;
void aidle(void* arg);
extern void userMain();
extern bool array_sleep[100];
extern void inicijalizuj_izlaz_ulaz();
int main()
{

    DoKernel=true;
    memory_initialize();
    DoKernel=false;
    inicijalizuj_izlaz_ulaz();
    DoKernel=true;
    kthread_create(&TCB::running,nullptr,nullptr,nullptr);
    DoKernel=false;
    DoKernel=true;
    kthread_create(&TCB::idle,aidle,nullptr,new uint64[DEFAULT_STACK_SIZE]);
    DoKernel=false;
    Riscv::w_stvec((uint64) &Riscv::supervisorTrap);
    Riscv::ms_sstatus(Riscv::SSTATUS_SIE);


    userMain();

    DoKernel=true;
    finidl=1;
    for(int k=0;k<100;k++){
        array_sleep[k]=false;
    }
    DoKernel=false;
    return 0;
}


void aidle(void* arg){
   while(!finidl){}
}