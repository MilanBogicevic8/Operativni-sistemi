//
// Created by marko on 20.4.22..
//

#include "../h/tcb.hpp"
#include "../h/riscv.hpp"

TCB *TCB::running = nullptr;
TCB *TCB::idle=nullptr;
extern void thread_dispatch();
int TCB::br=0;
uint64 TCB::timeSliceCounter = 0;
extern bool DoKernel;


TCB *TCB::createThread(Body body,void* arg,void* stack_space)
{
    DoKernel=true;
    TCB* tcb=new TCB(body,arg, TIME_SLICE,stack_space);
    DoKernel=false;
    /*int i=0;
    for(;i<100;i++){
        if(array_slobodno[i]==0)
            break;
    }
    if(i<100){
        TCB* node=&array_tcb[i];
        node->body=body;
        node->stack=(uint64*)(stack_space);
        node->context={(uint64) &threadWrapper,
                       node->stack != nullptr ? (uint64) &node->stack[STACK_SIZE] : 0
        };
        node->timeSlice=DEFAULT_TIME_SLICE;
        node->finished=false;
        node->arg=arg;
        node->stanje=READY;
        if (body != nullptr && br!=2) { Scheduler::put(node); }
        return node;
    }*/
    return tcb;
    //return nullptr;

}

void TCB::yield()
{
    uint64 sepc = Riscv::r_sepc();
    uint64 sstatus = Riscv::r_sstatus();
    TCB::timeSliceCounter = 0;
    TCB::running->stanje=READY;
    TCB::dispatch();
    Riscv::w_sstatus(sstatus);
    Riscv::w_sepc(sepc);
}

void TCB::dispatch()
{
    TCB *old = running;
    if (!old->isFinished()) { Scheduler::put(old); }
    running = Scheduler::get();
    running->stanje = READY;
    //Riscv::mc_sstatus(1<<8);
    TCB::contextSwitch(&old->context, &running->context);
}

void TCB::threadWrapper()
{
    Riscv::popSppSpie();

    running->body(running->arg);
    running->setFinished(true);
    running->stanje=FINISHED;
    thread_dispatch();
}



int kthread_create(thread_t* handle,void(*start_routine)(void*),void* arg,void* stack_space)
{
    *handle=TCB::createThread(start_routine,arg,stack_space);
    return 1;
}


int kthread_dispatch() {
    TCB::timeSliceCounter = 0;
    TCB::running->stanje=READY;
    TCB::dispatch();
    return 1;
}

int kthread_exit(){
    TCB::timeSliceCounter = 0;
    TCB::running->stanje=FINISHED;
    TCB::running->setFinished(true);
    /*if(TCB::running->stack) {
        delete TCB::running->stack;
    }*/
    TCB::dispatch();
    return 1;
}
