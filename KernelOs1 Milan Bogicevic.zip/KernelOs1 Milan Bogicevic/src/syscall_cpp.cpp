#include "../h/syscall_cpp.hpp"

bool array_sleep[100]={false};
static int num_sleepy=10;
extern volatile int finidl;

PeriodicThread::PeriodicThread(time_t periodical){
    this->periodical=periodical;
    array_sleep[num=num_sleepy++]=true;
}

void PeriodicThread::run(){
    while(array_sleep[num]) {
        aktivacija(this);
        time_sleep(periodical);
    }
}


