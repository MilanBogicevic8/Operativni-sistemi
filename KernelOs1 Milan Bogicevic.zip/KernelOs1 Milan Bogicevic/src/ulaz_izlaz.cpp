#include "../h/ulaz_izlaz.hpp"

static BNode slob[100];
static int bit_ni[100]={0};
BNode* head_p=nullptr,*tail_p=nullptr;
void blokiraj_nit_znak(){
    TCB::running->stanje=BLOCKED;
    TCB* oldThread=TCB::running;// running se blokira na semaforu

    //lista.addLast(oldThread);

    int i=0;
    for(;i<100;i++){
        if(bit_ni[i]==0){
            break;
        }
    }
    BNode* slo=&slob[i];
    slo->tcb=oldThread;
    slo->next=nullptr;
    if(i<100) {
        bit_ni[i]=1;
        if (tail_p) {
            tail_p->next = slo;
            tail_p = slo;
        } else {
            head_p = tail_p = slo;
        }

        TCB::running = Scheduler::get();// izvlaci se nova nit iz scheduler
        TCB::running->stanje = READY;
        TCB::contextSwitch(&oldThread->context, &TCB::running->context);
    }
}

void deblokiraj_nit_znak(){
    if (!head_p) { return; }

    BNode *elem = head_p;
    head_p = head_p->next;
    if (!head_p) { tail_p = nullptr; }

    TCB *thr = elem->tcb;

    int i=0;
    for(;i<100;i++){
        if(elem==&slob[i]){
            bit_ni[i]=0;
        }
    }
    thr->stanje=READY; // ovde se vadi iz reda blokiranih niti i stavlja u scheduler
    Scheduler::put(thr);
}